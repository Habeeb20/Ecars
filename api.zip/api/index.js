import express from "express"
import inventoryRoutes from "./routers/inventoryRoutes.js"
import dealerRoutes from "./routers/dealerRoutes.js"
import cors from "cors";
import dotenv from "dotenv";
import morgan from "morgan";
import { connectDb } from "./db.js";
import router from "./routers/userRouter.js";
import User from "./models/user.js";
import adminRouter from "./routers/adminRouter.js";
import carListingRouter from "./routers/carListingRoute.js"
import statsRoute from "./routers/statsRouter.js"
import reportRouter from "./routers/reportRoute.js";
import paymentRouter from "./routers/paymentRoute.js"
import plansRouter from "./routers/plansRoutes.js"
import valueRouter from "./routers/valueAssetsRoutes.js"
import blogRouter from "./routers/blogRouter.js"
import carPartRoute from "./routers/carPartListingRouter.js"
import messagesRoute from "./routers/messagesRouter.js"
import offerRouter from "./routers/offerRouter.js";
import contactRouter from "./routers/contactRoute.js"
import sightingRoutes from "./routers/SightingReport.js"
import dealsRoutes from "./routers/dealsRouter.js"
import distanceRouter from "./routers/distanceRoute.js"
import viewRouter from "./routers/carViewingRoute.js"
import salesRoutes from "./routers/salesRoute.js"
import eauctionRoutes from "./routers/auctionRoute.js"
import dealerVideoRoutes from "./routers/dealervideoRoutes.js"
dotenv.config();
connectDb()

const app = express()


app.use((req, res, next) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.set('Pragma', 'no-cache');
  res.set('Expires', '0');
  res.set('Surrogate-Control', 'no-store');
  next();
});


app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));
app.use(cors({
  origin: "*",
  methods: ["GET", "POST", "PUT", "DELETE"],
  credentials: true,
}));
app.use(morgan("dev"));

///routes
app.get("/", (req, res) => {
  res.send("ecars backend is listening on port....");
});



app.use("/api/users", router)
app.use("/api/car-viewings", viewRouter)
app.use("/api/auth", router)
app.use("/api/admin", adminRouter)
app.use("/api/cars", carListingRouter)
app.use("/api/car-listings", carListingRouter)
app.use("/api/stats", statsRoute)
app.use("/api/reports", reportRouter)
app.use("/api/payments", paymentRouter)
app.use("/api/subscriptions", plansRouter)
app.use("/api/value", valueRouter)
app.use("/api/blogs", blogRouter)
app.use("/api/carparts", carPartRoute)
app.use("/api/messages", messagesRoute)
app.use("/api/offers", offerRouter)
app.use("/api/contact", contactRouter)
app.use('/api/sighting', sightingRoutes);
app.use('/api/deals', dealsRoutes)
app.use('/api', distanceRouter);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/dealers', dealerRoutes);
app.use('/api/sales', salesRoutes);
app.use("/api/eauction", eauctionRoutes);
// app.js
app.use('/api/dealer-videos', dealerVideoRoutes);
// await User.create({
//   firstName: 'Admin',
//   lastName: 'Boss',
//   email: 'ecars@gmail.com',
//   password: 'essential01',
//   role: 'superadmin'
// });

// console.log('Superadmin created!');


// Start server
const port = process.env.PORT || 2020;

app.listen(port, async () => {
  console.log(`Server is running on port ${port}`);

})









































